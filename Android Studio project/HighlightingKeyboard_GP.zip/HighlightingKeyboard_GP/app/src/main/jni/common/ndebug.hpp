#ifndef NDEBUG__HPP
#define NDEBUG__HPP

#ifdef NDEBUG
#warning "Binaries compiled with NDEBUG defined are unsupported see http://aspell.net/ndebug.html."
#endif

#endif
