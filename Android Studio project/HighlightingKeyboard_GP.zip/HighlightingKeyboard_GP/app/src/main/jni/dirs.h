#define PREFIX "/sdcard/aspell"
#define DATA_DIR "<prefix>"
#define DICT_DIR "<prefix>"
#define CONF_DIR "<prefix>"
